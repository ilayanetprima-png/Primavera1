
Sistema de Reservas - Primavera Tours
====================================
Proyecto Flask + SQLite con Bootstrap.

Ejecutar:
  1. Crear y activar entorno virtual (opcional):
     python -m venv venv
     source venv/bin/activate   # Linux/Mac
     venv\Scripts\activate    # Windows PowerShell

  2. Instalar Flask:
     pip install flask

  3. Ejecutar la app:
     python app.py

Archivos incluidos:
  - app.py
  - database.db (se genera automáticamente con datos de ejemplo)
  - templates/ (archivos HTML con Bootstrap)
  - static/ (imagenes svg y css)
