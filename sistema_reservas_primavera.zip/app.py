from flask import Flask, render_template, request, redirect, send_from_directory
import sqlite3
from datetime import datetime
import os

PROJECT_ROOT = os.path.dirname(__file__)
DB_PATH = os.path.join(PROJECT_ROOT, 'database.db')

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute(\"\"\"CREATE TABLE IF NOT EXISTS paquetes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        destino TEXT NOT NULL,
                        precio REAL NOT NULL,
                        duracion TEXT NOT NULL,
                        imagen TEXT
                    )\"\"\")
    conn.execute(\"\"\"CREATE TABLE IF NOT EXISTS clientes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        email TEXT NOT NULL,
                        telefono TEXT NOT NULL
                    )\"\"\")
    conn.execute(\"\"\"CREATE TABLE IF NOT EXISTS reservas (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_cliente INTEGER,
                        id_paquete INTEGER,
                        fecha_reserva TEXT,
                        FOREIGN KEY(id_cliente) REFERENCES clientes(id),
                        FOREIGN KEY(id_paquete) REFERENCES paquetes(id)
                    )\"\"\")
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/paquetes')
def paquetes():
    conn = get_db_connection()
    paquetes = conn.execute('SELECT * FROM paquetes').fetchall()
    conn.close()
    return render_template('paquetes.html', paquetes=paquetes)

@app.route('/agregar_paquete', methods=['POST'])
def agregar_paquete():
    destino = request.form['destino']
    precio = float(request.form['precio'] or 0)
    duracion = request.form['duracion']
    imagen = request.form.get('imagen') or None
    conn = get_db_connection()
    conn.execute('INSERT INTO paquetes (destino, precio, duracion, imagen) VALUES (?, ?, ?, ?)',
                 (destino, precio, duracion, imagen))
    conn.commit()
    conn.close()
    return redirect('/paquetes')

@app.route('/clientes')
def clientes():
    conn = get_db_connection()
    clientes = conn.execute('SELECT * FROM clientes').fetchall()
    conn.close()
    return render_template('clientes.html', clientes=clientes)

@app.route('/agregar_cliente', methods=['POST'])
def agregar_cliente():
    nombre = request.form['nombre']
    email = request.form['email']
    telefono = request.form['telefono']
    conn = get_db_connection()
    conn.execute('INSERT INTO clientes (nombre, email, telefono) VALUES (?, ?, ?)',
                 (nombre, email, telefono))
    conn.commit()
    conn.close()
    return redirect('/clientes')

@app.route('/reservas')
def reservas():
    conn = get_db_connection()
    reservas = conn.execute(\"\"\"SELECT r.id, c.nombre AS cliente, p.destino AS destino, r.fecha_reserva
                               FROM reservas r
                               JOIN clientes c ON r.id_cliente = c.id
                               JOIN paquetes p ON r.id_paquete = p.id\"\"\").fetchall()
    clientes = conn.execute('SELECT * FROM clientes').fetchall()
    paquetes = conn.execute('SELECT * FROM paquetes').fetchall()
    conn.close()
    return render_template('reservas.html', reservas=reservas, clientes=clientes, paquetes=paquetes)

@app.route('/agregar_reserva', methods=['POST'])
def agregar_reserva():
    id_cliente = int(request.form['id_cliente'])
    id_paquete = int(request.form['id_paquete'])
    fecha = datetime.now().strftime(\"%Y-%m-%d\")
    conn = get_db_connection()
    conn.execute('INSERT INTO reservas (id_cliente, id_paquete, fecha_reserva) VALUES (?, ?, ?)',
                 (id_cliente, id_paquete, fecha))
    conn.commit()
    conn.close()
    return redirect('/reservas')

@app.route('/ventas')
def ventas():
    conn = get_db_connection()
    ventas = conn.execute(\"\"\"SELECT p.destino, COUNT(r.id) AS total_reservas, 
                             SUM(p.precio) AS total_ventas
                             FROM reservas r
                             JOIN paquetes p ON r.id_paquete = p.id
                             GROUP BY p.destino\"\"\").fetchall()
    conn.close()
    return render_template('ventas.html', ventas=ventas)

@app.route('/galeria')
def galeria():
    conn = get_db_connection()
    paquetes = conn.execute('SELECT * FROM paquetes').fetchall()
    conn.close()
    return render_template('galeria.html', paquetes=paquetes)

@app.route('/static/images/<path:filename>')
def static_images(filename):
    return send_from_directory(os.path.join(PROJECT_ROOT, 'static', 'images'), filename)

if __name__ == '__main__':
    init_db()
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM paquetes')
    if c.fetchone()[0] == 0:
        sample_paquetes = [
            ('París', 1200.00, '7 días', 'paris.svg'),
            ('Machu Picchu', 800.00, '5 días', 'machu_picchu.svg'),
            ('Salar de Uyuni', 600.00, '3 días', 'uyuni.svg'),
        ]
        c.executemany('INSERT INTO paquetes (destino, precio, duracion, imagen) VALUES (?, ?, ?, ?)', sample_paquetes)
    c.execute('SELECT COUNT(*) FROM clientes')
    if c.fetchone()[0] == 0:
        sample_clientes = [
            ('Linette Primavera', 'linette@example.com', '+59170000001'),
            ('Carlos Perez', 'carlos@example.com', '+59170000002'),
        ]
        c.executemany('INSERT INTO clientes (nombre, email, telefono) VALUES (?, ?, ?)', sample_clientes)
    c.execute('SELECT COUNT(*) FROM reservas')
    if c.fetchone()[0] == 0:
        c.execute('INSERT INTO reservas (id_cliente, id_paquete, fecha_reserva) VALUES (?,?,?)', (1,1,'2025-10-01'))
        c.execute('INSERT INTO reservas (id_cliente, id_paquete, fecha_reserva) VALUES (?,?,?)', (2,2,'2025-09-15'))
    conn.commit()
    conn.close()

    app.run(debug=True)
